## An English Template for Doctoral Thesis of Okumura-Funakoshi Group, Tokyo Institute of Technology

### Overleaf
- titech-lrlab-doctoral-thesis-template.zip

### Generated example
- main.pdf

### Acknowledgement

This repository was adapted from https://github.com/hiroshi-sasaki/thesis-template-ja
